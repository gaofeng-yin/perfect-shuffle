package aed_trabalho_n2;

import java.util.Arrays;
import java.util.Iterator;
import myCollections.ArrayDeque;

//import myCollections.ArrayDeque;
public class Baralho {

    private ArrayDeque<Carta> conteudo;
    public int ncarta;

    public Baralho(ArrayDeque<Carta> conteudo) {
        this.conteudo = conteudo;
    } // fim de construtor

    public Baralho(int numeroDeCartas) {
        this.ncarta = numeroDeCartas;
        if (ncarta % 2 != 0) {
            throw new UnsupportedOperationException("Erro! Insira um número par!");
        }
    } // 122fim de construtor

    /**
     * Devolve o conteúdo do baralho.
     *
     * @return o conteúdo do baralho.
     */
    public ArrayDeque<Carta> getConteudo() {

        conteudo = new ArrayDeque<Carta>();

        //Gera o conteudo do ArrayDeque com ncarta elementos para um Naipe
        //Retorna o ArrayDeque <Carta> que contem o Baralho Original
        int inc = ncarta + 1;

        for (int i = 1; i <= ncarta; i++) {
            inc--;

            Carta c = new Carta(Naipe.ESPADAS, inc);
            conteudo.addFirst(c);

        }
        return conteudo;
    }

    public boolean nextBaralho() {
        throw new UnsupportedOperationException("Método não implementado!");
    }

    /**
     * Executa o baralho perfeito in-shuffle.
     */
    public void inShuffle() {
        getConteudo();
        ArrayDeque<Object> baralhado = new ArrayDeque<Object>();

        Iterator iterador = conteudo.iterator();

        int z = 0;
        int count_InShuffle = 0;
        int count = 1;
        int i = 0;

        Object[] init;
        init = new Object[ncarta];

        while (iterador.hasNext()) {
            Object val = iterador.next();
            init[i] = val;
            i++;
        }

        Object[] arrBaralhado;
        arrBaralhado = new Object[ncarta];

        arrBaralhado = init.clone();

        Object[] superior;
        superior = new Object[ncarta / 2];

        Object[] inferior;
        inferior = new Object[ncarta / 2];
        //In-Shuffle
        while (z == 0) {

            System.out.println("\n--embaralhar #" + count + "--");
            System.out.println("IN-SHUFFLE");
            System.out.print("Baralho original: ");

            for (int p = 0; p < arrBaralhado.length; p++) {
                System.out.print(arrBaralhado[p] + " ");
            }

            System.out.print("\nMetade superior: ");

            for (int p = 0; p <= (ncarta / 2) - 1; p++) {
                superior[p] = arrBaralhado[p];
                System.out.print(superior[p] + " ");
            }

            System.out.print("\nMetade inferior: ");
            int e = 0;
            for (int p = (ncarta / 2); p <= (ncarta - 1); p++) {
                inferior[e] = arrBaralhado[p];
                System.out.print(inferior[e] + " ");
                e++;
            }

            if (!baralhado.isEmpty()) {
                while (!baralhado.isEmpty()) {
                    baralhado.removeFirst();
                }
            }

            System.out.print("\nBaralhado: ");
            for (int p = 0; p <= (ncarta / 2) - 1; p++) {
                baralhado.addLast(inferior[p]);
                baralhado.addLast(superior[p]);
            }

            Iterator iterador2 = baralhado.iterator();

            int c = 0;

            while (iterador2.hasNext()) {
                Object val = iterador2.next();
                arrBaralhado[c] = val;
                c++;
            }

            for (int p = 0; p <= (arrBaralhado.length - 1); p++) {
                System.out.print(arrBaralhado[p]);
            }

            count_InShuffle++;
            count++;

            if (Arrays.equals(init, arrBaralhado)) {
                z = 1;
            } else {
                z = 0;
            }
        }

        System.out.print(System.lineSeparator());
        System.out.println("Foi necessario " + count_InShuffle + " in-shuffles para voltar as " + ncarta + " cartas do baralho original!");
        System.out.print(System.lineSeparator());

    } // fim de inShuffle

    /**
     * Executa o baralho perfeito out-shuffle.
     */
    public void outShuffle() {
        getConteudo();
        ArrayDeque<Object> baralhado = new ArrayDeque<Object>();

        Iterator iterador = conteudo.iterator();

        int z = 0;
        int count_OutShuffle = 0;
        int count = 1;
        int i = 0;
        //Cria array init
        Object[] init;
        init = new Object[ncarta];

        while (iterador.hasNext()) {
            Object val = iterador.next();
            init[i] = val;
            i++;
        }

        Object[] arrBaralhado;
        arrBaralhado = new Object[ncarta];

        arrBaralhado = init.clone();

        Object[] superior;
        superior = new Object[ncarta / 2];

        Object[] inferior;
        inferior = new Object[ncarta / 2];
        //In-Shuffle
        while (z == 0) {

            System.out.println("\n--embaralhar #" + count + "--");
            System.out.println("IN-SHUFFLE");
            System.out.print("Baralho original: ");

            for (int p = 0; p < arrBaralhado.length; p++) {
                System.out.print(arrBaralhado[p] + " ");
            }

            System.out.print("\nMetade superior: ");

            for (int p = 0; p <= (ncarta / 2) - 1; p++) {
                superior[p] = arrBaralhado[p];
                System.out.print(superior[p] + " ");
            }

            System.out.print("\nMetade inferior: ");
            int e = 0;
            for (int p = (ncarta / 2); p <= (ncarta - 1); p++) {
                inferior[e] = arrBaralhado[p];
                System.out.print(inferior[e] + " ");
                e++;
            }
            
            if (!baralhado.isEmpty()) {
                while (!baralhado.isEmpty()) {
                    baralhado.removeFirst();
                }
            }

            System.out.print("\nBaralhado: ");
            for (int p = 0; p <= (ncarta / 2) - 1; p++) {
                baralhado.addLast(superior[p]);
                baralhado.addLast(inferior[p]);
            }

            Iterator iterador2 = baralhado.iterator();

            int c = 0;

            while (iterador2.hasNext()) {
                Object val = iterador2.next();
                arrBaralhado[c] = val;
                c++;
            }

            for (int p = 0; p <= (arrBaralhado.length - 1); p++) {
                System.out.print(arrBaralhado[p]);
            }

            count_OutShuffle++;
            count++;

            if (Arrays.equals(init, arrBaralhado)) {
                z = 1;
            } else {
                z = 0;
            }
        }

        System.out.print(System.lineSeparator());
        System.out.println("Foi necessario " + count_OutShuffle + " out-shuffles para voltar as " + ncarta + " cartas do baralho original!");
        System.out.print(System.lineSeparator());

    } // fim de outShuffle

    /**
     * Mover a carta de topo do baralho um determinado número de posições para
     * baixo do baralho.
     *
     * @param posicao o número de posições a mover.
     * @param messagens quando as mensagens devem ou não ser escritas.
     */
    public void moveTopo(int posicao, boolean messagens) {
        throw new UnsupportedOperationException("Método não implementado!");
    } // fim de moveTopo

} // fim de Baralho
