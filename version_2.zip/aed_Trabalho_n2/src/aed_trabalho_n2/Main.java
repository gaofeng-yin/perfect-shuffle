package aed_trabalho_n2;

import java.util.Scanner;

;

public class Main {

    public static void main(String[] args) {

        //input para inserir o num de cartas do baralho 
        Scanner scan = new Scanner(System.in);
        System.out.println("Insira o numero de cartas do baralho:");
        int card_number = scan.nextInt();

        Baralho b = new Baralho(card_number);
        System.out.println("---Testar Numero de In-Shuffles ate obter o baralho original---");
        b.inShuffle();
        System.out.println("---Testar Numero de Out-Shuffles ate obter o baralho original---");
        b.outShuffle();

    }

}
