package aed_trabalho_n2;

public enum Naipe {ESPADAS, PAUS, OUROS, COPAS}
